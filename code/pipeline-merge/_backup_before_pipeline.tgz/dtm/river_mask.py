import os

import geoutils as gu
import numpy as np
import rasterio
from numba import njit
from pyproj import Transformer
from rasterio.features import geometry_window
from rasterio.warp import transform_bounds
from scipy import ndimage
from shapely.geometry import box

from vertical_transform import DATA_DIR, load_file, result_path, save_raster

GAUSSIAN_SIGMA = 3
REGION_GROWING_VARIANCE_TOLERANCE = 0.02
SEED_VARIANCE_THRESHOLD = 9999
MASK_BUFFER_PIXELS = 0
MASK_NODATA = -1
CLASS_MASK_SUFFIX = "_classes_2018.tif"

COUNTRY_ALIASES = {
    "germany": ("germany", "nrw", "rhpf", "nisa", "bayern", "baden"),
    "france": ("france",),
    "netherlands": ("netherlands",),
    "switzerland": ("switzerland",),
    "liechtenstein": ("liechtenstein",),
}


def find_dem_files(directory=DATA_DIR):
    return sorted(
        os.path.join(directory, filename)
        for filename in os.listdir(directory)
        if filename.lower().endswith((".tif", ".tiff"))
        and not filename.lower().endswith(CLASS_MASK_SUFFIX)
        and not os.path.splitext(filename)[0].lower().endswith("_dep")
    )


def find_country_class_mask(country, directory=DATA_DIR):
    expected = f"{country}{CLASS_MASK_SUFFIX}".lower()
    for filename in os.listdir(directory):
        if filename.lower() == expected:
            return os.path.join(directory, filename)
    raise FileNotFoundError(
        f"No class mask named {country}{CLASS_MASK_SUFFIX} found in {directory}"
    )


def infer_country_name(dem_path):
    filename = os.path.basename(dem_path).lower()
    for country, aliases in COUNTRY_ALIASES.items():
        if any(alias in filename for alias in aliases):
            return country.title()
    raise ValueError(f"Could not determine the country from DEM filename: {dem_path}")


def load_country_water_mask(
    dem,
    country,
    buffer_pixels=MASK_BUFFER_PIXELS,
    directory=DATA_DIR,
):
    class_path = find_country_class_mask(country, directory)
    dem_crs = dem.crs
    dem_transform = dem.transform
    dem_height, dem_width = dem.shape

    with rasterio.open(class_path) as source:
        if source.crs is None:
            raise ValueError(f"Class mask has no CRS: {class_path}")
        source_crs = source.crs
        bounds_in_source_crs = transform_bounds(
            dem_crs,
            source_crs,
            *dem.bounds,
            densify_pts=21,
        )
        class_bounds = tuple(source.bounds)  # left, bottom, right, top
        if (
            bounds_in_source_crs[2] <= class_bounds[0]
            or bounds_in_source_crs[0] >= class_bounds[2]
            or bounds_in_source_crs[3] <= class_bounds[1]
            or bounds_in_source_crs[1] >= class_bounds[3]
        ):
            raise ValueError(
                f"{country} class mask does not overlap the DEM extent: {class_path}"
            )

        source_window = geometry_window(
            source,
            [box(*bounds_in_source_crs)],
            pad_x=1,
            pad_y=1,
        ).round_offsets().round_lengths()
        source_window = source_window.intersection(
            rasterio.windows.Window(0, 0, source.width, source.height)
        )
        source_array = source.read(1, window=source_window)
        source_transform = source.window_transform(source_window)

    # Each seed cell centre becomes a point, snapped to the DEM cell that contains it.
    rows, cols = np.nonzero((source_array == 2) | (source_array == 3))
    xs, ys = Transformer.from_crs(source_crs, dem_crs, always_xy=True).transform(
        source_transform.c + (cols + 0.5) * source_transform.a,
        source_transform.f + (rows + 0.5) * source_transform.e,
    )
    dem_cols = np.floor((xs - dem_transform.c) / dem_transform.a)
    dem_rows = np.floor((dem_transform.f - ys) / abs(dem_transform.e))
    inside = (  # comparisons are False for nan/inf, so failed transforms drop out
        (dem_rows >= 0) & (dem_rows < dem_height) & (dem_cols >= 0) & (dem_cols < dem_width)
    )

    mask = np.zeros((dem_height, dem_width), dtype=bool)
    mask[dem_rows[inside].astype(np.intp), dem_cols[inside].astype(np.intp)] = True
    if buffer_pixels:
        mask = ndimage.binary_dilation(
            mask,
            structure=np.ones((3, 3), dtype=bool),
            iterations=buffer_pixels,
        )
    print(f"Loaded {country} water mask: {np.count_nonzero(mask):,} cells")
    return mask


def river_mask_on_grid(dem_path, reference, buffer_pixels=0):
    """Boolean mask (True = river) of a DEM's river mask, resampled to `reference`'s grid."""
    basename = os.path.splitext(os.path.basename(dem_path))[0]
    mask_path = result_path(f"{basename}_river_mask.tif")
    if not os.path.isfile(mask_path):
        print(f"No river mask found for {basename}, skipping it", flush=True)
        return np.zeros(reference.shape, dtype=bool)

    river = gu.Raster(mask_path).reproject(reference, resampling="nearest")
    mask = river.data.filled(0) > 0        # region ids > 0; nodata (-1 / outside) counts as not-river
    del river
    if buffer_pixels:
        mask = ndimage.binary_dilation(
            mask, structure=np.ones((3, 3), dtype=bool), iterations=buffer_pixels
        )
    return mask


def make_gaussian_kernel(sigma=GAUSSIAN_SIGMA):
    if sigma <= 0:
        raise ValueError("Gaussian sigma must be greater than zero")
    radius = int(4 * sigma + 0.5)
    offsets = np.arange(-radius, radius + 1, dtype=np.float32)
    weights = np.exp(-0.5 * (offsets / sigma) ** 2)
    return weights / weights.sum()


@njit(cache=True)
def _reflect_index(index, length):
    while index < 0 or index >= length:
        if index < 0:
            index = -index - 1
        else:
            index = 2 * length - index - 1
    return index


@njit(cache=True)
def _local_variance_at(elevation, row, column):
    return elevation[row, column]


@njit(cache=True)
def _fill_seed_cache(elevation, seed_mask, variance_cache):
    height, width = elevation.shape
    for row in range(height):
        for column in range(width):
            if seed_mask[row, column]:
                variance_cache[row, column] = _local_variance_at(elevation, row, column)


@njit(cache=True)
def _grow_from_seeds(elevation, variance_cache, seeds, tolerance, valid_domain):
    height, width = elevation.shape
    flat_variance = variance_cache.ravel()
    flat_domain = valid_domain.ravel()
    labels = np.zeros(valid_domain.shape, dtype=np.int32)
    flat_labels = labels.ravel()

    # One cell is queued at most once overall, so the queue is reused for every region.
    queue = np.empty(flat_domain.size, dtype=np.int32)  # use int64 if N > 2**31
    region = 0
    for seed in seeds:
        if flat_labels[seed]:
            continue  # seed already consumed by an earlier region
        region += 1
        flat_labels[seed] = region
        queue[0] = seed
        head = 0
        tail = 1
        while head < tail:
            current = queue[head]
            head += 1
            row = current // width
            column = current - row * width
            current_variance = flat_variance[current]

            for row_offset in range(-1, 2):
                neighbor_row = row + row_offset
                if neighbor_row < 0 or neighbor_row >= height:
                    continue
                for column_offset in range(-1, 2):
                    if row_offset == 0 and column_offset == 0:
                        continue
                    neighbor_column = column + column_offset
                    if neighbor_column < 0 or neighbor_column >= width:
                        continue
                    neighbor = neighbor_row * width + neighbor_column
                    if flat_domain[neighbor] and not flat_labels[neighbor]:
                        if np.isnan(flat_variance[neighbor]):
                            flat_variance[neighbor] = _local_variance_at(
                                elevation, neighbor_row, neighbor_column
                            )
                        if abs(flat_variance[neighbor] - current_variance) <= tolerance:
                            flat_labels[neighbor] = region
                            queue[tail] = neighbor
                            tail += 1
    return labels


def grow_variance_regions(
    elevation,
    seed_mask,
    tolerance=REGION_GROWING_VARIANCE_TOLERANCE,
    valid_domain=None,
):
    if not np.isfinite(tolerance) or tolerance < 0:
        raise ValueError("Region-growing tolerance must be finite and non-negative")
    if elevation.shape != seed_mask.shape:
        raise ValueError("DEM and seed mask dimensions do not match")

    if valid_domain is None:
        valid_domain = np.isfinite(elevation)
    elif valid_domain.shape != elevation.shape:
        raise ValueError("DEM and valid-domain dimensions do not match")
    valid_domain = valid_domain & np.isfinite(elevation)
    seed_cells = seed_mask & valid_domain
    seeds = np.flatnonzero(seed_cells)          # flat indices, int64
    if seeds.size == 0:
        raise ValueError("Seed mask contains no valid cells")

    variance_cache = np.full(elevation.shape, np.nan, dtype=np.float32)
    _fill_seed_cache(elevation, seed_cells, variance_cache)

    keep = variance_cache.ravel()[seeds] <= SEED_VARIANCE_THRESHOLD
    discarded_count = int(np.count_nonzero(~keep))
    seeds = seeds[keep]

    print(
        f"Growing from {seeds.size:,} seeds; discarded {discarded_count:,} "
        f"whose minimum variance exceeds {SEED_VARIANCE_THRESHOLD:g} "
        f"(8-connected, tolerance {tolerance:g})"
    )
    # labels: 0 = not river, 1..R = regions, numbered in seed order
    labels = _grow_from_seeds(elevation, variance_cache, seeds, tolerance, valid_domain)
    return labels, seeds, seeds.size, variance_cache


def process_dem(dem_path, data_dir=DATA_DIR):
    country = infer_country_name(dem_path)
    print(f"\nProcessing {os.path.basename(dem_path)} ({country})")
    dem, _ = load_file(dem_path)
    water_mask = load_country_water_mask(dem, country, directory=data_dir)
    dem_values = np.asarray(dem.data.filled(np.nan), dtype=np.float32)
    dem_valid = np.isfinite(dem_values)
    elevation = np.where(dem_valid, dem_values, 0.0).astype(np.float32, copy=False)

    labels, seeds, _, variance = grow_variance_regions(
        elevation, water_mask, valid_domain=dem_valid
    )

    basename = os.path.splitext(os.path.basename(dem_path))[0]
    variance_path = result_path(f"{basename}_variance.tif")
    river_mask_path = result_path(f"{basename}_river_mask.tif")
    save_raster(
        variance,
        variance_path,
        dem.transform,
        dem.crs,
        np.nan,
        dtype="float32",
    )
    river_mask = labels
    river_mask[~dem_valid] = MASK_NODATA
    save_raster(
        river_mask,
        river_mask_path,
        dem.transform,
        dem.crs,
        MASK_NODATA,
        dtype="int32",
        resampling="NEAREST",  # region ids must not be averaged in overviews
    )
    print(
        f"Saved variance map and river mask: {seeds.size:,} accepted seeds in "
        f"{int(river_mask.max()):,} regions:\n  {variance_path}\n  {river_mask_path}"
    )

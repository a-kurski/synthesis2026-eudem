"""Reproducible AHN/NRW comparison."""
